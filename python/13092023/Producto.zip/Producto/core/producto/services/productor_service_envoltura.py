from api.payloads.request import ProductoRequest, ProductoActualizarRequest;
from api.payloads.response import Response
from infra.modelo import Producto;
from config.basededatos import BaseDeDatos
from sqlalchemy import and_

basededatos = BaseDeDatos()
engine = basededatos.obtener_conexion()

def agregar_producto_detalle(producto: ProductoRequest):
    nuevo_producto = Producto()
    nuevo_producto.id_producto = producto.id_producto
    nuevo_producto.nombre =  producto.nombre
    session = basededatos.obtener_sesion(engine)
    session.add(nuevo_producto)
    session.flush()
    session.refresh(nuevo_producto, attribute_names=['id_producto'])
    data = {"id_producto": nuevo_producto.id_producto, "nombre" : nuevo_producto.nombre}
    session.commit()
    session.close()
    return Response(data, 200, "El producto fue agregado satisfactoriamente.", False)

def leer_producto_detalle(id_producto: int):
    session = basededatos.obtener_sesion(engine);
    producto = session.query(Producto).filter( and_(Producto.id_producto == id_producto)).one()
    return producto;

def actualizar_producto_detalle(producto_actualizar_req : ProductoActualizarRequest, id_producto: int):
    session = basededatos.obtener_sesion(engine);
    productoActualizado = session.query(Producto).filter(Producto.id_producto == id_producto).update({
        Producto.nombre : producto_actualizar_req.nombre
    }, synchronize_session  = False);
    session.flush();
    session.commit();
    respuesta_mensaje = "El producto fue actualizado satisfactoriamente";
    response_code = 200;
    error = False
    if (productoActualizado == 1) :
        #Después de actualizar, recuperar el dato actualizado en la base de datos
        data = session.query(Producto).filter(Producto.id_producto == id_producto).one();
    elif (productoActualizado == 0):
        respuesta_mensaje = "El producto no fue actualizado. El producto no fue encontrado con el id " +  str(id_producto);
        error = True;
        data = None;
    return Response(data, response_code, respuesta_mensaje, error);


def eliminar_producto_detalle(id_producto : int):
    session = basededatos.obtener_sesion(engine);
    productoAEliminar = session.query(Producto).filter( and_(Producto.id_producto == id_producto)).one()
    session.delete(productoAEliminar);
    session.commit();
    response_msg = "El producto fue eliminado satisfactoriamente";
    response_code = 200;
    error = False;
    data = {"id_producto" : id_producto};
    return Response(data, response_code, response_msg, error);

def leer_todos_productos_detalle():
    session = basededatos.obtener_sesion(engine);
    data = session.query(Producto).all();
    return Response(data, 200, "Los productos son recuperados satisfactoriamente", False);
