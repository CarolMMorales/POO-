from core.producto.services.productor_service_envoltura import *;
from api.payloads.request import ProductoRequest, ProductoActualizarRequest;

async def agregar_producto_serv(producto: ProductoRequest):
    response = None;
    try:
        response = agregar_producto_detalle(producto);
    except Exception as ex:
        response = "El producto con id " + str(producto.id_producto) + " no fue encontrado";

    return response;

async def actualizar_producto_serv(producto_actualizar_req : ProductoActualizarRequest, id_producto: int):
    response_message = "El producto fue recuperado satisfactoriamente"
    data = None;
    error = True;
    try:
        response = actualizar_producto_detalle(producto_actualizar_req, id_producto);
    except Exception as ex:
        response = Response(data, 500, "Error al actualizar un producto: " + str(ex), error);

    return response;

async def eliminar_producto_serv(id_producto : int):
    data = None;
    error = True;
    try:
        response = eliminar_producto_detalle(id_producto);
    except Exception as ex:
        response = Response(data, 500, "Error al eliminar un producto: " + str(ex), error);

    return response;

async def leer_todos_productos_serv():
    return leer_todos_productos_serv();

async def leer_producto_serv(id_producto: int):
    response_message = "El producto fue recuperado satisfactoriamente"
    data = None;
    error = True;
    http = 200;
    try:
        data = leer_producto_detalle(id_producto);
    except Exception as ex:
        print(ex)
        response_message = "*** El producto con id " + str(id_producto) + " no fue encontrado";

    return Response(data, http, response_message, error)