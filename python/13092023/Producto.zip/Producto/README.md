# Ejemplo: FastAPI - API Product - Uniempresarial ISF12B

## Author
- [José Danilo Sánchez Torres]

## Prerrequisites
For the installation of this solution the following applications are required to be installed on a WINDOWS or Linux operating system:

- [Python](https://www.python.org/ftp/python/3.10.7/python-3.10.7-amd64.exe) - PYTHON v.3.10 (including PIP and adding to PATH)

## Installation of solution dependencies

This application is based on the use of some libraries (modules) in order to carry out the execution of the graphical interface component related to the initiative.

| Dependencies | Purpose |
| ------ | ------ |
| FastAPI| Microframework used for the management of APIs related to ELK components |
| Uvicorn | Library used to deploy the APIs related to the example from FAST API Framework |
| Requests | Library for handling HTTP request types in the software component |


The following instructions should then be executed via command line

Installing dependencies

```sh
  pip install -r requirements.txt
```

## Deploying solution

Once the source code has been downloaded, the following instruction must be executed, either from the integrated development environment called Pycharm or directly from the root folder of the project, using the following command:

```sh
 uvicorn main:uniempresarialISF12B --reload --port 9998
```
or

```sh
 python3 -m uvicorn main:uniempresarialISF12B --reload --port 9998
```

By default, the system will use the URL localhost(127.0.0.1) and port 8000, however, for this occasion port 9998 will be used.

```sh
127.0.0.1:9998
```

## Execution and example

For executing the solution, you must use the URL http://localhost:9998/docs


## License
MIT
