from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, INTEGER, String

Base = declarative_base()

class Producto(Base):
    __tablename__ = "PRODUCTO"
    id_producto = Column(INTEGER, primary_key=True)
    nombre = Column(String(100), nullable=False)
