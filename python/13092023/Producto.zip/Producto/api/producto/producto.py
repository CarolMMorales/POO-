from fastapi import APIRouter;
from core.producto.services.productor_service import *;
from api.payloads.request import ProductoRequest, ProductoActualizarRequest;

router = APIRouter(
    prefix="/api/v1/productos",
    tags=["Producto - Uniempresarial ISF12B"],
    responses={404: {"description": "Not found"}},
)

@router.post("/", response_description="Agregar producto")
async def agregar_producto(producto: ProductoRequest):
    response = None;
    try:
        response = await agregar_producto_serv(producto);
    except Exception as ex:
        print(ex)
        response = "El producto con id " + str(producto.id_producto) + " no fue encontrado";

    return response;

@router.put("/{id_producto}")
async def actualizar_producto(producto_actualizar_req : ProductoActualizarRequest, id_producto: int):
    response_message = "El producto fue recuperado satisfactoriamente"
    data = None;
    error = True;
    try:
        response = await actualizar_producto_serv(producto_actualizar_req, id_producto);
    except Exception as ex:
        response = Response(data, 500, "Error al actualizar un producto: " + str(ex), error);

    return response;

@router.delete("/{id_producto}")
async def eliminar_producto(id_producto : int):
    data = None;
    error = True;
    try:
        response = await eliminar_producto_serv(id_producto);
    except Exception as ex:
        response = Response(data, 500, "Error al eliminar un producto: " + str(ex), error);

    return response;

@router.get("/")
async def leer_todos_productos():
    return leer_todos_productos_detalle();

@router.get("/{id_producto}")
async def leer_producto(id_producto: int):
    response_message = "El producto fue recuperado satisfactoriamente"
    data = None;
    error = True;
    http = 200;
    try:
        data = await leer_producto_serv(id_producto);
    except Exception as ex:
        print(ex)
        response_message = "El producto con id " + str(id_producto) + " no fue encontrado";

    return Response(data, http, response_message, error)
