from fastapi import APIRouter
from api.producto import producto;

router = APIRouter()
router.include_router(producto.router)