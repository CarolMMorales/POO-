from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class ProductoRequest(BaseModel):
    nombre: str = Field(
        None, title="Nombre del Producto", max_length=100
    )
    id_producto: int = Field(..., gt=0,
                         description="Identificacion del producto")

class ProductoActualizarRequest(BaseModel):
    nombre: str = Field(
        None, title="Nombres del producto a modificar", max_length=1000
    )
    id_producto: int = Field(..., gt=0,
                         description="Identificacion del producto")
