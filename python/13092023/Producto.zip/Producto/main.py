from fastapi import FastAPI
from api.api import router as api_router

uniempresarialISF12B = FastAPI();
uniempresarialISF12B.include_router(api_router)
#http://localhost:9998/docs
#python3 -m uvicorn main:uniempresarialISF12B --reload --port 9998